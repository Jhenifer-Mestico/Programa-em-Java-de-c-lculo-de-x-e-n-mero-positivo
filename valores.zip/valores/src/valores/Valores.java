/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package valores;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class Valores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner inputData = new Scanner(System.in);
    System.out.println("Digite o valor de x:");
   int x = inputData.nextInt(); 
   
    System.out.println("Digite o valor de n positivo:");
   int n = inputData.nextInt();
   
   System.out.println("Resultado:" + xElevandonPositivo (x,n)); 
    }
    
    public static int xElevandonPositivo(int x, int n){
        if (n==0){
            return 1;
        } else {
            return x * xElevandonPositivo (x,n - 1);
        }
    }
}
